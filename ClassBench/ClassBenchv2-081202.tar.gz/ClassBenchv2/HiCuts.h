/*
 * HiCuts v1.0 : The source code for the HiCuts Algorithm
  * Authors: Yaxuan Qi,Baohua Yang<yangbaohua@gmail.com> 
 * Tsinghua NSLab
 * Create Time: 2007/4/24
 *
 * Modified by Baohua Yang during the Internship in IBM China Research Lab
 * 1) Interface to ClassBench+
 * 2) Big_Endean Porting onto Sun Niagara
 *
 * Last Modified: 2008/07/03
 */



#include"ClassBenchv2.h"

#ifndef __HICUTS_H__
#define __HICUTS_H__

//#define fatal(x, args...)  do { printf(x, ## args); exit(1); } while(0)
#define bug_on(x) do { if ((x)) { printf("** BUG at line %d\n" , __LINE__); }} while (0)
#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

/* globle variables */
typedef unsigned char   U8;
typedef unsigned short  U16;
typedef unsigned long   U32;

#ifndef true
#define true        1
#endif

#ifndef false
#define false       0
#endif

#ifndef bool
#define bool int
#endif

//////////////////////////////////////////////////////////////////////////
//parameters below will be loaded outside
static U8 IF_CUTS_HEURISTIC = 0;   //if get numcuts with heuristic,test if num_bit_cuts == -1
U8 NUM_BIT_CUTS = 8;            //num of bit to cut each time,-1:heuristic
U16 NUM_CUTS = 1<<8;            //num to cut<--------------
static U8 H2CDIM = 3;           //choose using which method to choose a dim
static U8 SM_WEIGTH1 = 0;       //2^{weight1}*sum_{i=1}^numCuts NumRules(child)
static U8 SM_WEIGTH2 = 0;       //2^{weight2}*np(C(v))
static U16 SPFAC = 4;           //space for each rule
static U16 BINTH = 1;           //maximum number of rules in leaf nodes <--------------
static U8 IF_NM = 1;    
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//parameters below will be calculated again in cpp
//#define SIZE_HABS 1
//#define SIZE_CPA_UNIT 1
//#define IF_HABS 0
#define SIZE_CON_POINTERS 1
//////////////////////////////////////////////////////////////////////////

#define SIZE_TREENODE   8       // memory size of treenode
#define INIT_NUM_CUTS   4       // the initial number of cut
#define NUMDIM          5       // filter dimensionality
#define MAXRULES        100000   // maximum number of rules
static U8 NUM_METHOD_H2CDIM = 4; //the number of methods

//////////////////////////////////////////////////////////////////////////
// For debug using
#define _DEBUG_				0		// 0 no debug; 1 debug
#define DISPLAY_ALL			0		// 0 no info; 1 display info
#define DISPLAY_LEAF		0		// 0 no info; 1 display info
#define DISPLAY_CUTINFO		0		// 0 no info; 1 display info
#define SUCCESS				0
#define FAIL				-1
#define NOTFOUND			-2		// Used in searching packet...
//int mem_rulelist=0;
//enum BOOL{FALSE = 0,TRUE = !FALSE};
//enum bool{false = 0,true = !FALSE};
// names of methods to choose d2c heuristically 
const char* Method_H2CDIM[] = {
	"Min the Max_NumRules of Child",
	"Max the Distribution's Entropy",
	"Min the Sm(C) over all Dimensions",
	"Most_Distinct_Components"
};

/************************************************************************/
/* Data structures                                                      */
//////////////////////////////////////////////////////////////////////////

//structures for filters
typedef struct {
		U32 	pos;				// the serial number of this filter in classifier 
		U32		ruleRange[NUMDIM][2];	// each rule expressed by ranges
}RULE;

struct RULESET {
		U32		numRules;			// total number of rules
		RULE	ruleList[MAXRULES];	// 
}gRuleSet;

// Decision tree structures
struct _TREENODE	{
	U8			d2c;			// log2(NBMAXDIMENSION) bits, Dimension to cut XXX FP second
	U8			b2c;			// Number of bits to cut: 0~31  XXX FP 3
//	U8			HABS;			// HABS string XXX FP
	struct _TREENODE	**ptr;	// Pointer array XXX FP
	U8			numCPA;			// CP for build aggTree
	U32 		depth;
    U32         numRules;       // number of rules
    U16         numCuts;        // number of Cuts
};// Node of tree
typedef struct _TREENODE TREENODE;

struct TREE {
	TREENODE	*root; 			// XXX FP first */
	U32			numLeafNodes; 	// The number of leaf nodes
	U32			maxDepth; 		// The maxdepth of the tree
	U32			sum_LeafDepth;  // statistics: depth sum
	float 		avgDepth; 		// statistics: the averagedepth;
	U32			numNode;		// number of nodes in tree
}gTree={NULL,0,0,0,0,0};//tree stucture

struct _STATE {
	U32			numRules;		// Number of the rules
	U32			*ruleList;		// Rule number list in this state
	U8			b2c[NUMDIM];	// Number of bits to cut,0xff means leaf
	U32			range[NUMDIM][2];
	TREENODE	*currTreeNode;
	struct _STATE *nextState;
};// help to build tree
typedef struct _STATE STATE;

//queue of states
struct STATEQUEUE {
	STATE		*headState;		//
	STATE		*rearState;		// I am a chain stack...
};

struct _QUEUENODE {
	TREENODE	*treeNode;
	U32		sNum;
	U32		sNumChild;
};
typedef struct _QUEUENODE QUEUENODE;

struct NODEQUEUE {
	QUEUENODE	*root;
	U32		numNode;
};

// cutinfo,help to build tree
struct _CUTINFO {
	U16	numUniqueCut;		// Number of the unique cuts
	U16	*ucID;				// Save the unique cut ID for every cut
	U32	*numRules;			// Number of rules in the corresponding unique cut
	U32	**ruleList;			// Rulelist in the corresponding cut
	int	*isUnique;			// Is a unique cut or not			
};
typedef struct _CUTINFO CUTINFO;


// Result structures
struct RESULTS {
float	avgDepth;			// Average Depth
U32		wstDepth;			// Worst case Depth
U32		numNodes;			// Number of nodes
U32		totalMem;			// Total memory used, unit is Byte
float	avgSearchTime;		// Average search time
U32		wstSearchTime;		// Worst case search time
U32		numPackets;			// Number of packets
}gResult={0,0,0,0,0,0,0};

//Packet structures
struct	_PACKETHEADER {
U32		sIP;		// Source IP
U32		dIP;		// Destination IP
U16		sPT;		// Source port
U16		dPT;		// Destination port
U8		proto;  	// protocol
U16		ruleNum;	// The number of rule which should deal with this packet
};
typedef struct _PACKETHEADER PACKETHEADER;

//meminfo
static struct {
	int alloc;
	int free;
	int max_size;
	int min_size;
} mem_info = { 0, 0, 0, 0xFFFFFFFF };
#define MEM_STATS_MAX 257
static int memstats[MEM_STATS_MAX];

/*{{{*/

//#if 1
//#include <stdint.h>
//typedef uint64_t U64;
//typedef union {
//	U64 u32;
//	struct {
//		U64 d2c:8;
//		U64 b2c:8;
//		U64 habs:8;
//		U64 addr:40;
//	} s;
//} AggTreeNode;
//#else
//typedef U32 AggTreeNode;
//#endif
//
//struct AggTREE {
//	AggTreeNode	*root;
//	U32		numNode;
//};
/*}}}*/
// Functions for building the decision tree
U8 isRuleRedundant(U32 curRuleNum,U32 *ruleList,U32 numRules);		// Check if rule redundant
int GetCutInfo(U8 *d2c, U8 *b2c, U32 *n2c, U32 *i2c, CUTINFO *h2c);
U8 Min_Max_NumRules_Child(CUTINFO **h2c,U32 *n2c,STATE *state);		// Minimize the max_j(NumRules(child_j))
U8 Max_Distribution_Entropy(CUTINFO **h2c,U32 *n2c,STATE *state); 	// Maximize the entropy of the distribution
U8 Min_Sm_Over_All_Dimensions(U32 *sm,STATE *state); 				// Minimize sm(C) in all dimensions
U8 Most_Distinct_Components(U16 *max_unique_id);					// Choose dimension by method 4:choose the dimension that has the most distinct components of rules
U16 genCPAnodeNum(U8 HABS, U16 nodeNum);
int BuildTree(void);												// Main function for building tree
U16 bitCount(U8 HABS,U8 length);										// Return the sum of the first length bits  in HABS
U8 getBit(U8 HABS,U8 bitPos);										// Return the specified bit value of HABS
void *bic_malloc(int size);
void bic_free(void *);
void bic_meminfo(void);
void bic_meminit(void);
U16 getLog_2(U32 num); //get log
int convRules(pFiltSet pfiltset);// Convert rules into gRuleSet
//API to ClassBenchv2
void HiCutsInit(pFiltSet pfiltset);
int HiCutsSearch(unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr);
int searchPacket(U32*ruleList,unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr,U32 numRules);
unsigned int LBConvL(unsigned int num);
unsigned short LBConvS(unsigned short num);
#endif
