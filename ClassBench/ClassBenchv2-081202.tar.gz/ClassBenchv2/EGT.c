/*****************************************************************************
 *	Implementation of the Extended Grid of Trie Algorithm
 *
 *	This code stack is developed partially based on the code from "Packet Classification Repository (PCR)"
 *	http://www.ial.ucsd.edu/ (not available now)	
 *	The original author is Sumeet Singh
 *
 *	The implementation of EGT is based on the HierarchyTrie
 *
 *	ClassBenchv2
 *	An tool to evaluate the real performance of the Packet Classification Algorithm.
 *	ClassBenchv2 uses the filter set from ClassBench
 *
 *	Interfaces from the Algorithms:
 *	void AlgorithmInit(struct FILTSET* filtset): 
 	    When this routine is called by ClassBenchv2, the algorithm would used "filtset " to 
 *    build up its data strutures
 *    
 *	int AlgorithmSearch(int destAddr, int srcAddr, int srcp, int dstp, int prot):
 *	    When this routine is called by ClassBenchv2, the algorithm would use the 5-tuple
 *    to search in its data structure and return the result;
 *
 *
 *
 *	Kai Zheng, IBM China Research Lab
 *	
 *	Last Update: Aug, 2008
 *
 *
 *
 *
 *	The original code seems not functionally correct. Basically the problem comes from
 *	the incorrect jump pointers...
 *	I also included in this revision the performance evaluation part and the  dumping 
 *	part
 *	Email: zhengkai@cn.ibm.com or zhengk@tsinghua.org.cn
 *
 *
 * **************************************************************************/
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdarg.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <memory.h>
#include <sys/types.h>

#include "ClassBenchv2.h"
#include "HierarchyTrie.h"
#include "EGT.h"

extern MASKS[];
extern MASKS2[];
extern PTrieSubNode  NewTrieSubNode();
extern void AddFilterToTrie(TrieNode * ptnode,PFilter pfilter,int rDim);
extern int CountDstNodes(PTrieNode cN,int flag2d);
extern int CountSrcNodes(PTrieNode cN);
extern void ValidateTrie(PTrieNode ptnode,unsigned int * valid);

TrieNode* CreateEGT(pFiltSet pfiltset,int rDim)
{
	int i;
	TrieNode *newNode = (TrieNode*) malloc(sizeof(struct TRIENODE));
	newNode->zero = NULL;
	newNode->one = NULL;
	newNode->src = NULL;
	newNode->pSNList=NULL;

 	for(i=0; i<pfiltset->numFilters; i++)
		AddFilterToTrie(newNode,&(pfiltset->filtArr[i]),rDim);

	return newNode;
}

// zk: 2008-5-27
/* Debug purpose only*/
int DumpSourceTrieNode(PTrieNode ptnode)
{
	int result=0;
	struct TRIESUBNODE* pd=ptnode->pSNList;
	
	while(pd)
	{
		printf(" %d",pd->cost);
		pd=pd->next;
		result++;
	}
	if(result)
		printf("<%d>",ptnode->level);
	
	  if (ptnode->zero)
			result+= DumpSourceTrieNode(ptnode->zero);

	  if (ptnode->one)	
			result+= DumpSourceTrieNode(ptnode->one);

	  return result;

}


/*The following 5 routines is from the orignal author*/
/*These routine are used to copy the filters to the children nodes of the 2nd level trie from any of their ancestors*/
/*So that no possible matching nodes would be missed when using a LPM style trie lookup scheme*/
void AddPointerToLastNode(PTrieNode ptnode, PTrieSubNode ptsubnode)
{
	PTrieSubNode currentSubNode;
	PTrieSubNode *pSN;

	
	if (!(ptnode->pSNList))
		ptnode->pSNList = ptsubnode;

	else	
	{
		currentSubNode = ptnode->pSNList;

		while(currentSubNode->next)// && ptsubnode->cost<currentSubNode->next->cost)	
			currentSubNode = currentSubNode->next;

		//ptsubnode->next=currentSubNode->next;
		currentSubNode->next=ptsubnode;
	}
	
}

int AddLinkToSubNode(PTrieNode start, PTrieSubNode ptsubnode)
{
	PTrieNode currentNode = start;

	if (!start) return 0;

	if (currentNode->pSNList)	{
		// printf("<Z>");
		AddPointerToLastNode(currentNode, ptsubnode);
		return (AddLinkToSubNode(currentNode->zero, currentNode->pSNList) + 
						AddLinkToSubNode(currentNode->one, currentNode->pSNList));
	}
	else	{
		return (AddLinkToSubNode(currentNode->zero, ptsubnode) + AddLinkToSubNode(currentNode->one, ptsubnode));
	}

	return 0;
}

void AddSubNodeToTrieBase(PTrieNode start)
{
	PTrieNode currentNode = start;
	int num=0;

	if (!(start)) return;

	if (currentNode->pSNList)	//currentNode should be a node on the 2nd level trie
	{
	 	num = (  AddLinkToSubNode(currentNode->zero, currentNode->pSNList) + 
				 AddLinkToSubNode(currentNode->one,  currentNode->pSNList));

	}
	else	{
		AddSubNodeToTrieBase(currentNode->src);
		AddSubNodeToTrieBase(currentNode->zero);
		AddSubNodeToTrieBase(currentNode->one);
	}
	return;
}



PTrieSubNode GetSubNode(PTrieNode start, unsigned int prefix, unsigned int prefixLen)
{
		PTrieNode currentNode=NULL;
		PTrieNode lastNode=NULL;
		PTrieSubNode ptsubnode=NULL;
		int i;

		if (!start) return NULL;

		if (!(start->src)) return (GetSubNode(start->parent, prefix,prefixLen));

		currentNode=start->src;

		i=0;
		while(currentNode && (i<prefixLen))
		{
			lastNode=currentNode;
			if (MSBBitX(prefix,i))
			{
				currentNode = currentNode->one;
			}
			else
			{
				currentNode = currentNode->zero;
			}

			i++;
		}

		if (currentNode)
			ptsubnode = currentNode->pSNList;
		else
			ptsubnode = lastNode->pSNList;

		return ptsubnode;

}

void AddLinksToSubNodes(PTrieNode start, PTrieNode lastGoodSource, unsigned int prefix, int prefixLen)
{
	PTrieNode currentNode;
	int num=0;
	PTrieSubNode tsubnode;


#if DEBUG 
	printf("L");
#endif

	if (!(start)) return;


	currentNode = start;

	if (lastGoodSource)
	{
#if DEBUG
		printf("GOT GOOD LAST SOURCE\n");
		if (!lastGoodSource->parent) printf("BUT NO PARENT\n");
#endif
		tsubnode = GetSubNode(lastGoodSource->parent, prefix, prefixLen);
		AddPointerToLastNode(currentNode, tsubnode);
	}

	// else
	{
		if (currentNode->src != NULL)
		{
			lastGoodSource = currentNode;
#if DEBUG
			printf("SET LAST GOOD SOURCE\n");
#endif
			AddLinksToSubNodes(currentNode->src,lastGoodSource, 0x0,0);
		}

	
		if (currentNode->zero) AddLinksToSubNodes(currentNode->zero, lastGoodSource, ((prefix>>1))    ,prefixLen+1);
		if (currentNode->one) AddLinksToSubNodes(currentNode->one,  lastGoodSource, ((prefix>>1)|0x80000000 ) ,prefixLen+1);
	}

#if DEBUG  
	printf("\n");
#endif

	return;
}

/*Find the jump pointer for a certain 2nd node*/
//PTrieNode start is a node on the 1st level trie, prefix indicates the path to find 2nd level trie node
PTrieNode FindJumpPointers(PTrieNode start, unsigned int prefix, int prefixLen)
{
	int i;
	PTrieNode cN = start;

	if (!cN)	
		return NULL;
	
#if DEBUG_JUMP
	printf("\n\t[0x%x/%d]",prefix, prefixLen); //zk
#endif
	

	if (!cN->src)	//zk: if the current 1st node do not have a 2nd level sub-trie, then search for its parent
		return FindJumpPointers(start->parent, prefix, prefixLen);

	cN = cN->src;  //zk: go down to the 2nd level trie
#if DEBUG_JUMP
	printf("[");
	DumpSourceTrieNode(cN);
	printf("] ");
#endif

	//zk: travel the 2nd level trie, using the same path to N
	for(i=0; ((cN) && (i<prefixLen)); i++)	
	{
#if LITTLE_ENDIAN //x86
		if (MSBBitX(prefix, 32-prefixLen+i))	
#else
		if (MSBBitY(prefix, 32-prefixLen+i))
#endif
		{
#if DEBUG_JUMP
			printf("F1");
#endif
			if(cN->one)
				cN = cN->one;
			else
				return cN;
		}
		else	
		{
#if DEBUG_JUMP
			printf("F0");
#endif
			if(cN->zero)
				cN = cN->zero;
			else
				return cN;
		}
	}

	if (cN)	
		return cN;
	else 
		return FindJumpPointers(start->parent, prefix, prefixLen);
}


/*update the Jump pointers on the whole trie, recursively*/
void UpdateJumpPointers(PTrieNode start, PTrieNode cDest,unsigned int prefix, int prefixLen, int dim)
{
	PTrieNode currentNode;
	PTrieNode tnode;

	if(!start) return;
	
	currentNode = start;
	

#if DEBUG_JUMP
	printf("\n(H:%d:%d:%d)", prefixLen, dim, (currentNode->zero || 0)+(currentNode->one || 0));
#endif

	if (dim==0)	//indicating we are still at the 1st level trie
	{
		if(currentNode->zero)
			UpdateJumpPointers(currentNode->zero, currentNode, ((prefix<<1)), prefixLen+1, 0);
		if(currentNode->one)
			UpdateJumpPointers(currentNode->one, currentNode, ((prefix<<1)|0x1 ), prefixLen+1, 0);
		if (currentNode->src) 
		{
#if DEBUG_JUMP 
			printf("D.", prefixLen, dim, (currentNode->zero || 0)+(currentNode->one || 0)); //zk
#endif
			UpdateJumpPointers(currentNode->src, currentNode, 0x0, 0, 1);
		}
			
	}
	else	//indicating we are at the 2nd level trie
	{
		if(currentNode->zero)
			UpdateJumpPointers(currentNode->zero, cDest, ((prefix<<1)), prefixLen+1, 1);
		if(currentNode->one)
			UpdateJumpPointers(currentNode->one, cDest, ((prefix<<1)|0x1 ), prefixLen+1, 1);

		if(!currentNode->zero || !currentNode->one)
			currentNode->jump = FindJumpPointers(cDest->parent, prefix, prefixLen);
		
		if(currentNode->jump == currentNode )
			currentNode->jump = NULL;
	
#if DEBUG_JUMP_S			
		if (currentNode->jump) 
		{
			printf("\n\t[0x%x/%d]  ",prefix, prefixLen); //zk
			printf("0x%x(%d)->0x%x(%d)[",currentNode, currentNode->level, currentNode->jump, currentNode->jump->level); //zk
			DumpSourceTrieNode(currentNode->jump);
			printf("] ");
		}
#endif
	}

}


/* Search Functions for Extended Grid-of-Trie */
void SearchEGTSource(PTrieNode ptnode, unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr, unsigned int * result)
{
	PTrieSubNode tpsubnode;
	PTrieNode pJump;

	while (ptnode)	
	{
		pJump=ptnode->jump;
		if (ptnode->pSNList)	
		{
			tpsubnode = ptnode->pSNList;
			
			while(tpsubnode) 
			{
				if (tpsubnode->cost>=*result) 
					break;
				
				if ( ((sp >= tpsubnode->fromPort[0]) && (sp <= tpsubnode->toPort[0])) && ((dp >= tpsubnode->fromPort[1]) && (dp <= tpsubnode->toPort[1])) )
					if (tpsubnode->protLen > 0 && pr == tpsubnode->protPref || tpsubnode->protLen==0)	
							*result=tpsubnode->cost;
				tpsubnode = tpsubnode->next;
			}

		}

		if (MSBBitX(source,ptnode->level))	
			ptnode = ptnode->one;
		else	
			ptnode = ptnode->zero;

	}

	// follow the jump pointer
	if(pJump)
		SearchEGTSource(pJump, dest, source, sp, dp, pr,result);
	

}

void SearchEGT(PTrieNode ptnode, unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr, unsigned int* result)
{
	PTrieNode lastGoodNode;
		
	while(ptnode)
	{
		if (ptnode->src) lastGoodNode=ptnode->src;

		if (MSBBitX(dest, ptnode->level))
			ptnode=ptnode->one;
		else 
			ptnode=ptnode->zero;
	}

	SearchEGTSource(lastGoodNode, dest, source, sp, dp, pr,result);
}

/*API to ClassBenchv2*/
void EGTInit(pFiltSet pfiltset)
{
	int i;
	
	for(i=0;i<MAXFILTERS;i++)
		validateEGT[i]=0;
		
	// After this statement, the trie structure is built, but the jump pointers were NOT set.
	//ZZT = NewTrieSubNode();
	EGT = CreateEGT(pfiltset,0);
	
	printf("\nStats for EGT \n");
	printf("# Nodes in 1st DIM: %d\n",CountDstNodes(EGT, 0));
	printf("# Nodes in 2nd DIM: %d\n",CountDstNodes(EGT, 1) - CountSrcNodes(EGT));
	ValidateTrie(EGT,validateEGT);

	// Routine to validate that all filters exist in the trie 
  	for(i=1;i<=pfiltset->numFilters;i++)
 		if (validateEGT[i]<1) 	printf("PLS CHECK: %d %d\n",i,validateEGT[i]);

	
	//	After this statement, any node in the trie contains all matched filters.
	//  Thus, during the search process, we don't have to keep the matched filters along 
	//  the path, the longest matched node contains a pointer to all matched filters.
	AddSubNodeToTrieBase(EGT);
		
	UpdateJumpPointers(EGT, EGT, 0x0, 0, 0);

	//DumpSourceTrieNode(EGT->src);
	
}

/*API to ClassBenchv2*/
int EGTSearch(unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr)
{
	unsigned int result=MAXFILTERS;
	PTrieSubNode tpsubnode;
	
	SearchEGT(EGT, dest, source, sp, dp, pr, &result);
	//There should be bugs in either SearchEGT() or AddSubNodeToTrieBase() or UpdateJumpPointers()
	//that in some case, the src trie of the root node is missed in the search path...
	//so we have to add the following additionally...
	SearchEGTSource(EGT->src, dest, source, sp, dp, pr,&result);

	return result;
}



