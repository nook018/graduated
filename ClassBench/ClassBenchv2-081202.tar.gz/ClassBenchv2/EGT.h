#ifndef GOT
#define GOT	1

/* Global Variables */

#define TRUE            1
#define FALSE           0

#define ERROR           (-1)
#define SUCCESS         1

#define MAX_STRIDE		8

#define DEBUG 			0
#define DEBUG_JUMP		0
#define DEBUG_JUMP_S	0

#define DEBUG_SEARCH 	0

#define max(X,Y)	( ((X)>(Y))?(X):(Y) )
#define min(X,Y)	( ((X)>(Y))?(Y):(X) )

// masks
#define HEXMinMask(A,B) ( (A) & ( ( ( 0xffffffff >>   ( 32 - B ) ) ) << (32-B) ) )
#define HEXMaxMask(A,B)	((B==32)?(A):( (A) |  ( 0xffffffff >> (B) ) ))
#define BitX(A,X)		( ((A)&MASKS[(X%32)])?1:0)
#if LITTLE_ENDIAN //x86
#define MSBBitX(A,X)	( ((A)&MASKS[(32-(X))])?1:0)
#else
#define MSBBitX(A,X)	( ((A)&MASKS[(32-(X))])?1:0)
#define MSBBitY(A,X)	( ((A)&MASKS2[(32-(X))])?1:0)
#endif


TrieNode *EGT;

unsigned int validateEGT[MAXFILTERS];

#endif


