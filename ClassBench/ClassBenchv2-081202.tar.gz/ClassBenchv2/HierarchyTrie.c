
/*****************************************************************************
 *	Implementation of the Hierarchy Trie Algorithm
 *
 *	This code stack is developed partially based on the code from "Packet Classification Repository (PCR)"
 *	http://www.ial.ucsd.edu/ (not available now)	
 *	The original author is Sumeet Singh
 *
 *
 *	ClassBenchv2
 *	An tool to evaluate the real performance of the Packet Classification Algorithm.
 *	ClassBenchv2 uses the filter set from ClassBench
 *
 *	Interfaces from the Algorithms:
 *	void AlgorithmInit(struct FILTSET* filtset): 
 	    When this routine is called by ClassBenchv2, the algorithm would used "filtset " to 
 *    build up its data strutures
 *    
 *	int AlgorithmSearch(int destAddr, int srcAddr, int srcp, int dstp, int prot):
 *	    When this routine is called by ClassBenchv2, the algorithm would use the 5-tuple
 *    to search in its data structure and return the result;
 *
 *
 *
 *	Kai Zheng, IBM China Research Lab
 *	
 *	Last Update: Aug, 2008
 *
 *
 *
 *
 *	The original code seems not functionally correct. Basically the problem comes from
 *	the incorrect jump pointers...
 *	I also included in this revision the performance evaluation part and the result dumping 
 *	part
 *	Email: zhengkai@cn.ibm.com or zhengk@tsinghua.org.cn
 *
 *
 * **************************************************************************/
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdarg.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <memory.h>
#include <sys/types.h>
#include "ClassBenchv2.h"
#include "HierarchyTrie.h"

#if LITTLE_ENDIAN //x86
unsigned int MASKS[] = { 0x00000000, 
	0x00000001, 0x00000002, 0x00000004, 0x00000008, 0x00000010, 0x00000020, 0x00000040, 0x00000080, 
	0x00000100, 0x00000200, 0x00000400, 0x00000800, 0x00001000, 0x00002000, 0x00004000, 0x00008000, 
	0x00010000, 0x00020000, 0x00040000, 0x00080000, 0x00100000, 0x00200000, 0x00400000, 0x00800000, 
	0x01000000, 0x02000000, 0x04000000, 0x08000000, 0x10000000, 0x20000000, 0x40000000, 0x80000000 };
#else
unsigned int MASKS[] = { 0x00000000, 
	0x01000000, 0x02000000, 0x04000000, 0x08000000, 0x10000000, 0x20000000, 0x40000000, 0x80000000,
	0x00010000, 0x00020000, 0x00040000, 0x00080000, 0x00100000, 0x00200000, 0x00400000, 0x00800000, 
	0x00000100, 0x00000200, 0x00000400, 0x00000800, 0x00001000, 0x00002000, 0x00004000, 0x00008000, 
	0x00000001, 0x00000002, 0x00000004, 0x00000008, 0x00000010, 0x00000020, 0x00000040, 0x00000080
 	 };
unsigned int MASKS2[] = { 0x00000000, 
	0x00000001, 0x00000002, 0x00000004, 0x00000008, 0x00000010, 0x00000020, 0x00000040, 0x00000080, 
	0x00000100, 0x00000200, 0x00000400, 0x00000800, 0x00001000, 0x00002000, 0x00004000, 0x00008000, 
	0x00010000, 0x00020000, 0x00040000, 0x00080000, 0x00100000, 0x00200000, 0x00400000, 0x00800000, 
	0x01000000, 0x02000000, 0x04000000, 0x08000000, 0x10000000, 0x20000000, 0x40000000, 0x80000000 };

#endif

PTrieSubNode  NewTrieSubNode()
{
	PTrieSubNode ptsubnode = (TrieSubNode*) calloc (1,sizeof(struct TRIESUBNODE));

	if (!ptsubnode)
	{
		printf("out of memory\n");
		exit(ERROR);
	}
	ptsubnode->next = NULL;
	
	return ptsubnode;
}

/* Add the filter to the list of the 2nd level trie, stored in the increasing order of the cost value*/
void AddFilterToNode(PTrieNode ptnode, PFilter pfilter)
{
	PTrieSubNode *pSN, ptsubnode = NewTrieSubNode();

	ptsubnode->protPref = pfilter->protPref;
	ptsubnode->protLen = pfilter->protLen;
	ptsubnode->fromPort[0] = pfilter->fromPort[0];
	ptsubnode->fromPort[1] = pfilter->fromPort[1];
	ptsubnode->toPort[0] = pfilter->toPort[0];
	ptsubnode->toPort[1] = pfilter->toPort[1];
	//ptsubnode->act = pfilter->action;
	//ptsubnode->pfilter = pfilter;
	ptsubnode->cost = pfilter->cost;
	ptsubnode->next = NULL;

	if (ptnode->pSNList != NULL)	// the node already contains filter(s)
	{
		pSN=&(ptnode->pSNList); //zk: store the filter in the increasing order of cost (the head unit is with the lowest cost)
		while((*pSN)->next)
		{
			if(ptsubnode->cost < (*pSN)->cost)
			{
				ptsubnode->next = *pSN;
				*pSN = ptsubnode;
				return;
			}
			pSN=&((*pSN)->next);
		}
		(*pSN)->next=ptsubnode;
	}
	else	// insert the first filter
		ptnode->pSNList = ptsubnode;
	
}

PTrieNode NewTrieNode()
{
	PTrieNode ptnode = (TrieNode*) calloc (1,sizeof(struct TRIENODE));
	if (ptnode == NULL)
	{
		printf("out of meory\n");
		exit(ERROR);
	}
	ptnode->zero = NULL;
	ptnode->one = NULL;
	ptnode->src = NULL;
	//ptnode->tempFiltCount = 0;
	ptnode->pSNList=NULL;
	ptnode->level=0;
	//ptnode->longestPath=0;

	return ptnode;
}

/* Add a filter to the Trie*/
void AddFilterToTrie(TrieNode* ptnode, PFilter pfilter, int rDim)
{

	int i,j;
	TrieNode* currentNode = ptnode;
	int prefixesTillNow=0;

	unsigned int destPref = pfilter->ipHEX[1];
	unsigned int destLen =  pfilter->len[1];
	unsigned int sourcePref = pfilter->ipHEX[0];
	unsigned int sourceLen = pfilter->len[0];
	int filtID = pfilter->cost;
	unsigned int prefix = 0x0;

	if (rDim)
	{
		destPref = pfilter->ipHEX[0];
		destLen = pfilter->len[0];
		sourcePref =  pfilter->ipHEX[1];
		sourceLen =  pfilter->len[1];
	}

	//currentNode->prefix = 0x0;

	//	Insert a new node in the Dst trie and 
	for(i=0; i<destLen; i++)
	{
		if (currentNode->src) prefixesTillNow++;

		if (MSBBitX(destPref,i))
		{
			if (currentNode->one != NULL)
				currentNode = currentNode->one;

			else
			{
				currentNode->one = NewTrieNode();
				currentNode->one->parent = currentNode;
				currentNode->one->level = currentNode->level + 1;
				currentNode = currentNode->one;
			}
			//prefix = prefix << 1 | 0x1;
			//currentNode->prefix = prefix;
		}
		else
		{
			if (currentNode->zero != NULL)
				currentNode = currentNode->zero;
			else
			{
				currentNode->zero = NewTrieNode();
				currentNode->zero->parent = currentNode;
				currentNode->zero->level = currentNode->level + 1;
				currentNode = currentNode->zero;

			}
			//prefix = prefix << 1 | 0x0;
			//currentNode->prefix = prefix;
		}
	}
	//currentNode->validPrefixes++;
	//currentNode->prefixesTillNow = prefixesTillNow+1;

	//	Move to the second-level trie, or 
  	//prefixesTillNow=0;
	if (currentNode->src)	// move to 
	{
		currentNode = currentNode->src;
		if(currentNode->cost>pfilter->cost) //zk
			currentNode->cost=pfilter->cost; //zk
	}
	else										// generate a new node
	{
		currentNode->src = NewTrieNode();
		currentNode->src->parent = currentNode;
		currentNode->src->level = 0;
		currentNode->src->cost = pfilter->cost; //zk
		currentNode = currentNode->src;
	}

	//	Insert a new node in the second-level trie and 
	for(j=0; j<sourceLen; j++)
	{
		if (currentNode->pSNList) prefixesTillNow++;

		if (MSBBitX(sourcePref,j))
		{
			if (currentNode->one != NULL)
			{
				if(currentNode->cost <  currentNode->one->cost)   //zk
					currentNode->one->cost = currentNode->cost ;  //zk
				currentNode = currentNode->one;
				
			}
			else
			{
				currentNode->one = NewTrieNode();
				currentNode->one->parent = currentNode;
				currentNode->one->level = currentNode->level + 1;
				currentNode->one->cost =  currentNode->cost;  //zk
				currentNode = currentNode->one;
			}
		}
		else
		{
			if (currentNode->zero != NULL)
			{
				if(currentNode->cost <  currentNode->zero->cost)   //zk
					currentNode->zero->cost = currentNode->cost ;  //zk
				currentNode = currentNode->zero;
			}
			else
			{
				currentNode->zero = NewTrieNode();
				currentNode->zero->parent = currentNode;
				currentNode->zero->level = currentNode->level + 1;
				currentNode->zero->cost =  currentNode->cost;  //zk
				currentNode = currentNode->zero;
			}
		}

	}

	AddFilterToNode(currentNode,pfilter);

	// update stat 
	//currentNode->prefixesTillNow = prefixesTillNow+1;
	//currentNode->tempFiltCount++;
	//currentNode->validPrefixes++;

}


/* For algorithm storage requirement analysis*/
int CountSrcNodes(PTrieNode cN)
{
	if (!cN) return 0;

	return( 1+CountSrcNodes(cN->zero) + CountSrcNodes(cN->one));
}

/* For algorithm storage requirement analysis*/
int CountDstNodes(PTrieNode cN, int flag2d)
{
	int i=0;
	int j=0;
	int k=0;

	if(!cN) return 0;

	i=CountDstNodes(cN->zero,flag2d);
	j=CountDstNodes(cN->one,flag2d);

	if (cN->src && flag2d)
	{
		k = CountSrcNodes(cN->src);
		return (1+i+j+k);
	}

	return(1+i+j);
	
}

/* Create a H-Trie, return the pointer to the root node*/
TrieNode* CreateTrie(pFiltSet pfiltset,int rDim)
{
	int i;
	TrieNode *newNode = (TrieNode*) malloc(sizeof(struct TRIENODE));
	newNode->zero = NULL;
	newNode->one = NULL;
	newNode->src = NULL;

 	for(i=0; i<pfiltset->numFilters; i++)
		AddFilterToTrie(newNode,&(pfiltset->filtArr[i]),rDim);

	return newNode;
}

/* Search the 2nd level H-Trie, match the rest 3 Dim at the leaf node*/
void SearchSourceTrie(PTrieNode ptnode, unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr, int * result)
{
	PTrieSubNode tpsubnode;

	while (ptnode)	
	{
		if (ptnode && ptnode->pSNList)	
		{
			tpsubnode = ptnode->pSNList;
			
			while(tpsubnode) 
			{
				if (tpsubnode->cost>=*result) 
				{
					tpsubnode = tpsubnode->next;
					break;
				}
				
				if ( ((sp >= tpsubnode->fromPort[0]) && (sp <= tpsubnode->toPort[0])) && ((dp >= tpsubnode->fromPort[1]) && (dp <= tpsubnode->toPort[1])) )
					if (tpsubnode->protLen > 0 && pr == tpsubnode->protPref || tpsubnode->protLen==0)	
							*result=tpsubnode->cost;
					
				tpsubnode = tpsubnode->next;
			}

		}

		if (MSBBitX(source,ptnode->level))	
		{
			if (ptnode->one) 
				ptnode = ptnode->one;
			else break;
		}
		else	
		{
			if (ptnode->zero) 
				ptnode = ptnode->zero;
			else break;
		}

		if (!ptnode)	
			break;

	}

}

/*Search the 1st level trie*/
void SearchTrie(PTrieNode ptnode, unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr, int* result)
{
	while(ptnode)
	{
		// All possible 2nd level trie would be visited
		if (ptnode->src && ptnode->src->cost < *result) SearchSourceTrie(ptnode->src, dest, source, sp, dp, pr,result);

		if (MSBBitX(dest, ptnode->level))
			ptnode=ptnode->one;
		else 
			ptnode=ptnode->zero;
	}
}

/* Chech whether or not all filters can be found on the H-Trie*/
void ValidateTrie(PTrieNode ptnode, unsigned int* valid)
{

	PTrieSubNode	tpsubnode;

	if (!ptnode) return;
	ValidateTrie(ptnode->zero, valid);
	ValidateTrie(ptnode->one, valid);
	ValidateTrie(ptnode->src, valid);
	
	if (ptnode->pSNList)
	{
		tpsubnode=ptnode->pSNList;
		while(tpsubnode)
		{
			valid[tpsubnode->cost]++;
			tpsubnode=tpsubnode->next;
		}
	}



}

/* API between CalssBenchv2*/
void HTInit(pFiltSet pfiltset)
{
	int i;
	
	for(i=0;i<MAXFILTERS;i++)
		validate[i]=0;
		
	// After this statement, the trie structure is built, but the jump pointers were NOT set.
	trieroot = CreateTrie(pfiltset,0);
	printf("\nStats for HT \n");
	printf("# Nodes in 1st DIM: %d\n",CountDstNodes(trieroot, 0));
	printf("# Nodes in 2nd DIM: %d\n",CountDstNodes(trieroot, 1) - CountDstNodes(trieroot, 0));
	ValidateTrie(trieroot,validate);

	// Routine to validate that all filters exist in the trie 
  	for(i=1;i<=pfiltset->numFilters;i++)
 		if (validate[i]<1) 	printf("PLS CHECK: %d %d\n",i,validate[i]);
	
}

/* API between CalssBenchv2*/
int HTSearch(unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr)
{
	int result=MAXFILTERS;
	
	SearchTrie(trieroot, dest, source, sp, dp, pr, &result);
	return result;
}


