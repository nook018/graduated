echo Generating Trace File...
# Generate trace "tcpdump2_acl1_10K.trace", 
# using "acl1_10K_trace.txt" as the pkt_hdr specification file and
# "tcpdump.2" as the original traffic trace file (real pkt trace)
./ClassBenchv2 -t acl1_trace.txt -T tcpdump.2 -w tcpdump2_acl1.trace
echo
echo Benchmarking the PC Algorithm
# Process the modified trace file "tcpdump2_acl1_10K.trace",
# Using PC rule set "acl1_10K.txt". 
# log the error result to file "log" (-e option means log the error result only)
./ClassBenchv2 -f acl1.txt -T tcpdump2_acl1.trace -l log -e

