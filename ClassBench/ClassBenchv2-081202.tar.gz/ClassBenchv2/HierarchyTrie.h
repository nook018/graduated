#ifndef HT
#define HT	1


#define TRUE            1
#define FALSE           0

#define ERROR           (-1)
#define SUCCESS         1

#define max(X,Y)	( ((X)>(Y))?(X):(Y) )
#define min(X,Y)	( ((X)>(Y))?(Y):(X) )

// masks
#define HEXMinMask(A,B) ( (A) & ( ( ( 0xffffffff >>   ( 32 - B ) ) ) << (32-B) ) )
#define HEXMaxMask(A,B)	((B==32)?(A):( (A) |  ( 0xffffffff >> (B) ) ))

#define BitX(A,X)		( ((A)&MASKS[(X%32)])?1:0)
#if LITTLE_ENDIAN //x86
#define MSBBitX(A,X)	( ((A)&MASKS[(32-(X))])?1:0)
#else
#define MSBBitX(A,X)	( ((A)&MASKS[(32-(X))])?1:0)
#define MSBBitY(A,X)	( ((A)&MASKS2[(32-(X))])?1:0)
#endif



struct TRIESUBNODE {
	unsigned char  protPref;
	unsigned char  protLen;
	unsigned int fromPort[2];
	unsigned int toPort[2];
	//unsigned char  act;
	unsigned int	cost;
	//struct FILTER   *pfilter;
	struct TRIESUBNODE* next;
	//struct TRIESUBNODE* nextI[3];
};

typedef struct TRIESUBNODE TrieSubNode;
typedef struct TRIESUBNODE* PTrieSubNode;

struct TRIENODE{
	struct TRIENODE *zero;
	struct TRIENODE *one;
	struct TRIENODE *src;
	struct TRIENODE *parent;
	struct TRIENODE *jump;
	struct TRIESUBNODE* pSNList;
	//struct TRIESUBNODE* pdimListI[3];
	unsigned char  level;
	//int tempFiltCount;
	//int longestPath;
	unsigned int cost; //zk: the lowest cost of the filters under this node (SourceTrie) 
	//unsigned int prefix;
	//unsigned int validPrefixes;
	// int filtID[MAXFILTERS];
	//unsigned int prefixesTillNow;
};

typedef struct TRIENODE TrieNode;
typedef struct TRIENODE* PTrieNode;

/* Global Variables */

// pointer to root node
TrieNode *trieroot;
// TrieNode *trierootR;

unsigned int validate[MAXFILTERS];

#endif

