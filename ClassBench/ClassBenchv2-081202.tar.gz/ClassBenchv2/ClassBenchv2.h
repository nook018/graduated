#define MAXFILTERS 		80000
#define MAX_PACKET		100000
#define MAX_THREAD		40

#define u_int8_t unsigned char
#define u_int16_t unsigned short
#define u_int32_t unsigned int

#include <pcap.h>

struct ETHER_HDR
{
	u_int8_t	ether_dhost[6];
	u_int8_t	ether_shost[6];
	u_int16_t	ether_type;
};
struct IP_HDR
{
	u_int8_t	ip_vhl; 	/* header length, version */
	u_int8_t	ip_tos; 	/* type of service */
	u_int16_t	ip_len; 	/* total length */
	u_int16_t	ip_id;		/* identification */
	u_int16_t	ip_off; 	/* fragment offset field */
	u_int8_t	ip_ttl; 	/* time to live */
	u_int8_t	ip_p;		/* protocol */
	u_int16_t	ip_sum; 	/* checksum */
	u_int32_t	ip_src; 	
	u_int32_t 	ip_dst;		/* source and dest address */
};
struct L4_HDR
{
	u_int16_t  src_port;
  	u_int16_t  dst_port;
 
};



struct FILTER  			// == 24 bytes..
{
	//unsigned int filterID;			
	unsigned int cost;			// 4 bytes
	unsigned char  pref[2][4];	// 4 + 4 bytes
	unsigned int ipHEX[2];
	unsigned char  len[2];			// 1 + 1 bytes
	unsigned int fromPort[2];		// 2 + 2 bytes
	unsigned int toPort[2];		// 2 + 2 bytes
	unsigned char  protPref;		// 1 byte
	unsigned char  protLen;		
	//unsigned char  action;			// 1 byte
};

struct HEADER
{
	unsigned int pktID;
	unsigned int SrcIP;
	unsigned int DstIP;
	unsigned int SrcPort;
	unsigned int DstPort;
	unsigned char  Prot;
	unsigned int matchFilterID;
};

typedef struct FILTER* PFilter;
typedef struct FILTER* Filter;

struct FILTSET
{
	unsigned int numFilters;
	struct FILTER filtArr[MAXFILTERS];
};

struct HEADERTRACE
{
	unsigned int numHdr;
	struct HEADER hdrtrace[MAX_PACKET];
};


typedef struct FILTSET* pFiltSet;
typedef struct HEADERTRACE* pHdrTrace;

typedef struct _threadarg_t {
	unsigned int nThreadID;
	unsigned int Iteration;
	unsigned int nPktLookup;
	unsigned int *ResultArr;
	struct HEADER *hdrtrace;
	int (*pPCSearch)(unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr);
	pcap_t *pd;
	unsigned int nByte;
	unsigned char bLog;
	
} ThreadArg_t;


