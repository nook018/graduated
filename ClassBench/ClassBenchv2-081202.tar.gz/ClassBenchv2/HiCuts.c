/*
 * HiCuts v1.0 : The source code for the HiCuts Algorithm
  * Authors: Yaxuan Qi,Baohua Yang<yangbaohua@gmail.com> 
 * Tsinghua NSLab
 * Create Time: 2007/4/24
 *
 *
 *
 *
 * Modified by Baohua Yang during the Internship in IBM China Research Lab
 * 1) Interface to ClassBench+
 * 2) Big_Endean Porting onto Sun Niagara
 *
 * Last Modified: 2008/07/03
 */
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif


#ifdef WINDOWS
#include <STDIO.H>
#include <STDLIB.H>
#include <MEMORY.H>
#include <WINDOWS.H>
#include <CONIO.H>
#include <MATH.H>
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <getopt.h>
#include <assert.h>
#include <unistd.h>
#endif

#include "HiCuts.h"

//#define fatal(x, args...)  do { printf(x, ## args); exit(1); } while(0)
#define bug_on(x) do { if ((x)) { printf("** BUG at line %d\n" , __LINE__); }} while (0)
#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

static FILE *fpr, *fpt;
static int verbose = 0;
static int do_agg = 0;
static int do_print = 0;
static U16 log_table[512];
/* global variables*/
extern struct RULESET gRuleSet;
static struct NODEQUEUE gNodeQueue;
extern struct RESULTS gResult; 	//result
extern struct TREE gTree;		// Tree
static struct STATEQUEUE gStateQueue = { NULL, NULL };

//API to ClassBenchv2
void HiCutsInit(pFiltSet pfiltset)
{
    int i=0;
    for(i=0;i<512;i++)
    {
        log_table[i]= getLog_2(i);
    }
    //printf("begin Init..\n");
    if(convRules(pfiltset)==FAIL)
    {
        printf("ERROR with HiCuts convRules()...\n");
        return;
    }

    if(BuildTree()!=SUCCESS)
        printf("ERROR with HiCuts BuildTree()...\n");
    printf("gTree.numNode=%u\n",gTree.numNode);
    //printf("end Init..\n");
}
/*
int HiCutsSearch_c(unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr)
{
   U16 nodeNum=0;
//return nodeNum;
   U16 CPAnodeNum=0,d2c=0,b2c=0,*ruleList=NULL,offset=0,offset_bit=0;
   TREENODE *currTNode;

   currTNode = gTree.root;
//printf("Normal Classify:\n");
while (currTNode->d2c != 0xff) 
{// search till a leaf node
//while (currTNode->HABS!=0){
d2c = currTNode->d2c;
offset_bit = NUM_BIT_CUTS; // the bit length for numCuts
//b2c = currTNode->b2c - offset_bit; // the bit length for child cuts
b2c = (4-currTNode->b2c)*NUM_BIT_CUTS - offset_bit;
offset = ~0x0; // offset = 11111...111
offset = ~(offset>>offset_bit<<offset_bit);   // JMG XXX offset is u16

switch (d2c) 
{
case 0:	nodeNum	= offset&(source>b2c); break;
case 1:	nodeNum	= offset&(dest>>b2c); break;
case 2:	nodeNum	= offset&(sp>>b2c); break;
case 3:	nodeNum	= offset&(dp>>b2c); break;
case 4:	nodeNum	= offset&(pr>>b2c); break;
//nodeNmju = offset&(packet[x]>>b2c); //more dimensions
default:
printf("d2c=%u:Invalid Packet Header!!\n\n\n\n",d2c);
exit(FAIL);
}
CPAnodeNum = genCPAnodeNum(currTNode->HABS,nodeNum);
if (do_print)
printf("basic HABS=%x d2c=%d b2c=%d nodeNum=%d CPA=%d\n", currTNode->HABS, d2c, b2c, nodeNum, CPAnodeNum);
//printf("class:oldnodenum=%d,CPAnodeNum=%d\n",currTNode->no,CPAnodeNum);
currTNode = currTNode->ptr[CPAnodeNum];
//printf("class:newcurrnode=%u\n",currTNode->no);
}

ruleList = (U16*) currTNode->ptr; // the leaf node
//printf("class_result:nodeaddr=%x,treenodenum=%d\n",(U32)(currTNode),currTNode->no);
return (U16)ruleList[0];
}
 */

int HiCutsSearch(unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr)
{
#ifdef LITTLE_ENDIAN //x86
    U32 destIP=dest;
    U32 srcIP=source;
#else
    U32 destIP=LBConvL(dest);
    U32 srcIP=LBConvL(source);
#endif

    U16 proto = (U16)pr;
    //printf("%u %u %u %u %u\n",srcIP,destIP,sp,dp,proto);
    U16 nodeNum=0,d2c=0,b2c=0,num=0,depth=0,offset=0,offset_bit = 0;
    TREENODE *currTNode;
    U32 *ruleList = NULL;

    currTNode = gTree.root;
    depth = 0;
    while (currTNode->d2c!=0xff) //not a leaf_node
    {
        //depth++;
        //assert(currTNode->numCuts != 0);
        offset_bit = log_table[currTNode->numCuts]; //the bit length for numCuts
        //assert(offset_bit != (U16)FAIL);
        b2c = currTNode->b2c - offset_bit; //the bit length for child cuts
        d2c = currTNode->d2c;
        //offset = ~0x0; //offset = 0xffff
        offset = ~((0xffff>>offset_bit)<<offset_bit); 
        //printf("d2c=%u\n",d2c);
        switch (d2c) {
            case 0:	nodeNum	= offset&(srcIP>>b2c);break;
            case 1:	nodeNum	= offset&(destIP>>b2c); break;
            case 2:	nodeNum	= offset&(sp>>b2c); break;
            case 3:	nodeNum	= offset&(dp>>b2c); break;
            case 4:	nodeNum	= offset&(proto>>b2c); break;
            default:
                    printf("d2c=%u:Invalid Packet Header!!\n\n\n\n",d2c);
                    exit(FAIL);
        }
        currTNode = currTNode->ptr[nodeNum];
        //printf("nodeNum=%u\n",nodeNum);
    }
    ruleList = (U32*) currTNode->ptr;
    
    if(BINTH==1)//only one rule
    {
        //printf("result=%u\n",(U32)(*ruleList)+1);
        return (int)(*ruleList)+1; //for rule begin with 1
    }

    //linear searching
    U32 ruleNum = searchPacket(ruleList,destIP,srcIP,sp,dp,proto,currTNode->numRules);
    if (ruleNum == (U32)FAIL)
    {
        printf("ERROR:while search packet,ruleNum=%u\n",ruleNum);
        return 0; //return the default rule
    }
    else
    {
        //printf("ruleNum=%u\t",ruleNum);
        return ruleNum+1;//for rule begin with 1
    }
}

//get the ruleNum in the leafNode,using linear search currently
int searchPacket(U32 *ruleList,unsigned int dest, unsigned int source, unsigned int sp, unsigned int dp, unsigned char pr,U32 numRules)
{
    U32 i = 0;
    for (i=0;i<numRules;i++)
    {
        if( (gRuleSet.ruleList[ruleList[i]].ruleRange[0][0] <= source)
         && (gRuleSet.ruleList[ruleList[i]].ruleRange[0][1] >= source)
         && (gRuleSet.ruleList[ruleList[i]].ruleRange[1][0] <= dest)
         && (gRuleSet.ruleList[ruleList[i]].ruleRange[1][1] >= dest)
         && (gRuleSet.ruleList[ruleList[i]].ruleRange[2][0] <= sp)
         && (gRuleSet.ruleList[ruleList[i]].ruleRange[2][1] >= sp)
         && (gRuleSet.ruleList[ruleList[i]].ruleRange[3][0] <= dp)
         && (gRuleSet.ruleList[ruleList[i]].ruleRange[3][1] >= dp)
         && (gRuleSet.ruleList[ruleList[i]].ruleRange[4][0] <= pr)
         && (gRuleSet.ruleList[ruleList[i]].ruleRange[4][1] >= pr)
          )
        {
            return ruleList[i];
        }
    }
    if(_DEBUG_) printf("ERROR:while searchPacket,NOT FOUND MATCHING!\n");
    return FAIL;
}

unsigned int LBConvL(unsigned int num)
{
    unsigned int mask1=0x000000ff;
    unsigned int mask2=0x0000ff00;
    unsigned int mask3=0x00ff0000;
    unsigned int mask4=0xff000000;

    return ((num&mask1)<<24)^((num&mask2)<<8)^((num&mask3)>>8)^((num&mask4)>>24);
}

unsigned short LBConvS(unsigned short num)
{
    unsigned short mask1=0x00ff;
    unsigned short mask2=0xff00;

    return ((num&mask1)<<8)^((num&mask2)>>8);
}

//malloc
void *bic_malloc(int size)
{
    void *p;
    if (size>mem_info.max_size)
        mem_info.max_size = size;
    if (size<mem_info.min_size)
        mem_info.min_size = size;
    mem_info.alloc += size;
    if (size< MEM_STATS_MAX)
        memstats[size]++;
    p = malloc(size);
    if (p)
        memset(p, 0, size);
    return p;
}

//free
void bic_free(void *p)
{
    free(p);
}

//init
void bic_meminit(void)
{
    memset(memstats, 0, sizeof(memstats));
}

//get meminfo
void bic_meminfo(void)
{
    int i;
    printf("alloc: %d bytes min=%d max=%d\n" , 
            mem_info.alloc,
            mem_info.min_size,
            mem_info.max_size);
    for (i=0; i<MEM_STATS_MAX; i++)
        if (memstats[i])
            printf(" %d alloc size %d\n" , memstats[i], i);

}

// get log_2^(num)
U16 getLog_2(U32 num)
{
    U16 i = 0;
    U32 temp = 1;
    while (temp < num)
    {
        i++;
        temp = temp<<1;
    }
    /*if (temp != num)
    {
        printf("ERROR:getlog of %u\nNot a power of 2\n",num);
        return FAIL;
    }*/
    return i;
}


// check for all the rulesets to find if this rule is redundant
/* ruleNum:origin serial num for current rule
ruleList:rulelist exsited in the cut now
numRules:number for the rules in the cut now*/
U8 isRuleRedundant(U32 curRuleNum,U32 *ruleList,U32 numRules)
{
    return 0;
    U32 i=0,j=0;
    U8 ifRedundant = 0;
    U16 preRuleNum = 0;

    for (i=0;i<numRules;i++)
    {
        ifRedundant = 1; // for each rule,set to 1 first
        preRuleNum = ruleList[i]; // get the origin serial rule num in the classifier
        for (j=0;j<NUMDIM;j++) // check all dimensions
        {
            if ((gRuleSet.ruleList[curRuleNum].ruleRange[j][0] < gRuleSet.ruleList[preRuleNum].ruleRange[j][0])
              ||(gRuleSet.ruleList[curRuleNum].ruleRange[j][1] > gRuleSet.ruleList[preRuleNum].ruleRange[j][1])) 
            {
                ifRedundant = 0; // not redundant for this dim
                break;
            }
        }
        if (ifRedundant == 1) // redundant
        {
            return 1;
        }
    }
    return 0; // no preRules contain this rule
}


#ifdef USE_ENTROPY
// caculate the entropy of a certain dimension
double getEntropy(CUTINFO *h2c,U32 n2c)
{
    double result = 0.0;
    double sum_numRule = 0.0;
    U32 i =0;
    // get the sum of all numRule
    for (i=0;i<n2c;i++)
    {
        sum_numRule += h2c->numRules[i];
    }
    for (i=0;i<n2c;i++)
    {
        if (h2c->numRules[i]>0)
        {
            result += (double)h2c->numRules[i]*log((double)h2c->numRules[i]/sum_numRule)/sum_numRule;
        }

        //JMG else if ((h2c->numRules[i]<0)&&(_DEBUG_))
        else if ((h2c->numRules[i]==0)&&(_DEBUG_))
        {
            printf("ERROR!numRule=%u\n",h2c->numRules[i]);
        }
    }

    return result;
}
#endif


// calculate out how to cut
// XXX JMG: seems that any bic_malloc will be freed => local memory for build
int GetCutInfo(U8 *d2c, U8 *b2c, U32 *n2c, U32 *i2c, CUTINFO *h2c)
{
    //printf("GetCutInfo\n");
    // temporary variable
    //U8            t_d2c[DIM]; // dimension to i
    //U8            t_b2c[DIM]; // bit to i
    U32         t_n2c[NUMDIM]; // number of cuttings
    U32         t_i2c[NUMDIM]; // interval of each cutting
    CUTINFO*    t_h2c[NUMDIM]; // how to i
    int prevCut;
    U16     t_max_unique_id[NUMDIM] =  {0, 0, 0, 0,0}; //number of unique i component
    STATE   *currState  =   gStateQueue.headState;
    U32     num,currRange[2],rangeSpan,sm[NUMDIM],spmf;
    U8      dim,ifUnique = 0;
    U32     *tRuleList  =   (U32*) malloc(currState->numRules*sizeof(U32));
    U32 n = currState->numRules; //number of rules in current node
    spmf = SPFAC * n;
    U32 NumCuts = 0;//need to prove
    U32 ruleNum = 0;
    U32 i = 0,j = 0,done = 0; //temporarily
    U32 Max_NumCuts = 0; //if b2c is little, we mustn't get a larger NumCuts
    //////////////////////////////////////////////////////////////////////////
    for (dim=0; dim<NUMDIM; dim++)//find a optimal num2Cut
    {
        //printf("dim=%u\n",dim);
        /*t_h2c in dimension whose'b2c =0 is not initialed*/
        //if (currState->b2c[dim] <= 0) t_n2c[dim] = 1;
        if (currState->b2c[dim] > 0) //1,2...or more bits
        {   // for an valid dim
            //printf("b2c=%u\n",currState->b2c[dim]);
            if(DISPLAY_CUTINFO) {
                printf("\n\nNew Dim\n");
                printf("b/2c = %d\n",currState->b2c[dim]);
            }
            if (currState->b2c[dim] >= 32) //the upper limit
            {
                Max_NumCuts = 1<<16; //need to prove
          //      printf("max_numcuts=%u\n",Max_NumCuts);
            }
            else //0 < b2c < 32
            {
                Max_NumCuts = 1<<(currState->b2c[dim]);
                if(DISPLAY_ALL) printf("Max_NumCuts = %u\n",Max_NumCuts);
            }

            if (currState->b2c[dim] > 2)
            {
                NumCuts = INIT_NUM_CUTS;
            }
            else //b2c[dim]<2,just use a little number
            {
                NumCuts = Max_NumCuts;
            }
            if(DISPLAY_CUTINFO) printf("NumCuts = %u\n",NumCuts);
            sm[dim] = 0; 
            t_h2c[dim] = (CUTINFO*)malloc(sizeof(CUTINFO));

            for(done=0;done==0;) // find a heuristic NumCuts
            {
                //printf("begin numcuts heuristics...\n");
                //if not using heuristics to decide the numcuts
                if(IF_CUTS_HEURISTIC == 0)
                {
                    NumCuts = NUM_CUTS; 
                    //printf("NumCuts=%u\n",NumCuts);
                    done = 1;
                }

                t_max_unique_id[dim] = 0; //clear the id for a new NumCuts
                sm[dim] = 0; //clear the sm for a new NumCuts,for every new NumCuts

                if (NumCuts == 0)
                {
                    printf("ERROR01:getLog_2\n");
                }

                //t_i2c[dim] = 0x1 << (currState->b2c[dim] - getLog_2(NumCuts));  // need to prove;
                t_i2c[dim] = 0x1 << (currState->b2c[dim] - log_table[NumCuts]);  // need to prove;
                //printf("dim=%u b2c=%u NumCuts=%u logcuts=%u i2c=%u\n",dim,currState->b2c[dim],NumCuts,log_table[NumCuts],t_i2c[dim]);
                rangeSpan = currState->range[dim][1]-currState->range[dim][0]; //the range between
                //printf("dim=%u %u:%u DIMrangeSpan=%u\n",dim,currState->range[dim][0],currState->range[dim][1],rangeSpan);

                t_h2c[dim]->ucID = (U16*)malloc(sizeof(U16)*NumCuts);
                t_h2c[dim]->numRules = (U32*)malloc(sizeof(U32)*NumCuts);
                t_h2c[dim]->ruleList = (U32**)malloc(sizeof(U32*)*NumCuts);
                t_h2c[dim]->isUnique = (bool*)malloc(sizeof(bool)*NumCuts);

                // record info of each cut part
                for (i=0; i<NumCuts; i++)//for each i segment
                { 
                    t_h2c[dim]->isUnique[i] = false; //set to false first
                    //find the range for each i
                    currRange[0] = currState->range[dim][0] + t_i2c[dim]*i;
                    currRange[1] = currRange[0] + t_i2c[dim] - 1;
                    //printf("dim=%u i=%u rangeSpan=%u:%u\n",dim,i,currRange[0],currRange[1]);

                    //initial the i info
                    t_h2c[dim]->ucID[i] = t_max_unique_id[dim]; //get a unique serial no of i
                    t_h2c[dim]->numRules[i] = 0; //initial no rule in i
                    t_h2c[dim]->ruleList[i] = NULL;

                    // get i info... currState->ruleList[num]
                    // just got the serial num of rule
                    ruleNum = 0;
                    for (num=0; num<n; num++)// for each rule,test if colliding with cuts
                    {
                        ruleNum = currState->ruleList[num];// get the origin serial num of current rule
                        //printf("ruleNum=%u,dim=%u,ruleRange:%u:%u\n",ruleNum,dim,gRuleSet.ruleList[ruleNum].ruleRange[dim][0],gRuleSet.ruleList[ruleNum].ruleRange[dim][1]);

                        // for full covered rules
                        // i      |------|
                        // Rule   <------>
                        if ( gRuleSet.ruleList[ruleNum].ruleRange[dim][0] <= currRange[0]
                          && gRuleSet.ruleList[ruleNum].ruleRange[dim][1] >= currRange[1])
                        {
                            if (t_h2c[dim]->numRules[i] <= 1) { //no preRules existing
                                tRuleList[t_h2c[dim]->numRules[i]]   = ruleNum;
                                t_h2c[dim]->numRules[i]++;                                                               
                            }
                            else //check for rule redundant with preRules belong with the same Cut
                                if(isRuleRedundant(ruleNum,tRuleList,t_h2c[dim]->numRules[i] - 1) == 0){ 
                                tRuleList[t_h2c[dim]->numRules[i]]   = ruleNum;
                                t_h2c[dim]->numRules[i]++;
                            }
                        }
                        // i |------|
                        // Rule   >-------
                        // for partial covered rules: lower in
                        else if (( gRuleSet.ruleList[ruleNum].ruleRange[dim][0] > currRange[0]
                               && gRuleSet.ruleList[ruleNum].ruleRange[dim][0] <= currRange[1])
                               ||( gRuleSet.ruleList[ruleNum].ruleRange[dim][1] >= currRange[0]
                               && gRuleSet.ruleList[ruleNum].ruleRange[dim][1] < currRange[1])) 
                        {
                            if (t_h2c[dim]->numRules[i] <= 1) { //no preRules existing
                                t_h2c[dim]->ucID[i] = t_max_unique_id[dim]+1; // new unique i
                                tRuleList[t_h2c[dim]->numRules[i]] = ruleNum;
                                t_h2c[dim]->numRules[i]++;
                            }
                            else if (isRuleRedundant(ruleNum,tRuleList,t_h2c[dim]->numRules[i]-1) == 0){ //check for rule redundant with preRules belong with the same Cut
                                t_h2c[dim]->ucID[i] = t_max_unique_id[dim]+1; // new unique i
                                tRuleList[t_h2c[dim]->numRules[i]] = ruleNum;
                                t_h2c[dim]->numRules[i]++;
                            }
                        }

                        // i      |-------|
                        // Rule  ------<
                        /*else if ( gRuleSet.ruleList[ruleNum].ruleRange[dim][1] >= currRange[0]
                               && gRuleSet.ruleList[ruleNum].ruleRange[dim][1] < currRange[1])// for partial covered rules: upper in
                        {
                            if (t_h2c[dim]->numRules[i] <= 1){ //no preRules existing
                                t_h2c[dim]->ucID[i] = t_max_unique_id[dim]+1; // new unique i
                                tRuleList[t_h2c[dim]->numRules[i]] = ruleNum;
                                t_h2c[dim]->numRules[i]++;
                            }
                            else if (isRuleRedundant(ruleNum,tRuleList,t_h2c[dim]->numRules[i]-1) == 0)
                            { //check for rule redundant with preRules belong with the same Cut
                                t_h2c[dim]->ucID[i] = t_max_unique_id[dim]+1; // new unique i
                                tRuleList[t_h2c[dim]->numRules[i]] = ruleNum;
                                t_h2c[dim]->numRules[i]++;
                            }
                        }*/
                        else
                        {
                            // does not fall in,do nth
                        }                       
                    } // end for each rule in i
                    //printf("check uniqueness\n");

                    // check uniqueness... <this might be made by hashing>
                    if ((t_h2c[dim]->ucID[i] == t_max_unique_id[dim]+1) || (i == 0))
                    {// a unique i
                        ifUnique = 1;
                    }
                    else
                    {
                        ifUnique = 1;   // Not the same with any previous cuttings

                        // compare with previous cuttings
                        for (prevCut = i-1; prevCut != -1; prevCut --)
                        {
                            if (t_h2c[dim]->numRules[i] !=  t_h2c[dim]->numRules[prevCut])
                            {
                                continue;// Nums of rules in cuts are not equal,:the two cuts are not equal.
                                // continue test for next i
                            }
                            else
                            { // compare the rules with previous unique i's
                                ifUnique = 0;
                                for (num=0; num < t_h2c[dim]->numRules[i]; num++) //the preCuts
                                {
                                    if (tRuleList[num] != t_h2c[dim]->ruleList[prevCut][num])
                                    {// there's a different rule# in the two rule lists
                                        ifUnique = 1;
                                        break;
                                    }
                                } // for each rule in a previous i

                                // if have found a equal prevCut,just copy the ucID,numRule and ruleList
                                if (ifUnique == 0)
                                {
                                    t_h2c[dim]->ucID[i]     =   t_h2c[dim]->ucID[prevCut];
                                    t_h2c[dim]->numRules[i] =   t_h2c[dim]->numRules[prevCut];
                                    t_h2c[dim]->ruleList[i] =   t_h2c[dim]->ruleList[prevCut];
                                    break; // break for search previous i
                                }
                            }
                        } // end for (prevCut = i-1; prevCut != -1; prevCut --) // for each previous cuttings
                    } // compare with previous cuttings

                    //for a new unique i, add into the t_h2c
                    if (ifUnique == 1)
                    {
                        t_h2c[dim]->isUnique[i] = true;
                        t_max_unique_id[dim]++;
                        t_h2c[dim]->ucID[i] = t_max_unique_id[dim];
                        t_h2c[dim]->ruleList[i] =   (U32*) malloc(t_h2c[dim]->numRules[i]*sizeof(U32));
                        memcpy(t_h2c[dim]->ruleList[i], (U32*)tRuleList, t_h2c[dim]->numRules[i]*sizeof(U32));
                        sm[dim] += t_h2c[dim]->numRules[i]<<SM_WEIGTH1;//add the number of rules in the unique i to sm
                    }
                } // end: for (i=0; i<NumCuts; i++)       

                //this is meaningless as the follow judge
                if (NumCuts > Max_NumCuts)
                {
                    printf("ERROR:%d:NumCuts > Max_NumCuts\t%u\t%u\n",dim,NumCuts,Max_NumCuts);
                    printf("ERROR:%d:b2c = %d\t,Max_NumCuts=%u\n",dim,currState->b2c[dim],Max_NumCuts);
                    return 0;
                }

                sm[dim] += NumCuts<<SM_WEIGTH2;
                //some may need NumCuts > 256
                if ((IF_CUTS_HEURISTIC == 1)&&(sm[dim] + NumCuts < spmf)&&(NumCuts < Max_NumCuts)) //not get the optimal Number of Cuts, and not overflow
                {
                    free(t_h2c[dim]->ucID);
                    t_h2c[dim]->ucID = NULL;
                    free(t_h2c[dim]->numRules);
                    t_h2c[dim]->numRules = NULL;
                    for (i=0;i<NumCuts;i++)
                    {
                        if (t_h2c[dim]->isUnique[i] == true)
                        {
                            free(t_h2c[dim]->ruleList[i]);
                            t_h2c[dim]->ruleList[i] = NULL;
                        }
                    }

                    free(t_h2c[dim]->ruleList);
                    t_h2c[dim]->ruleList = NULL;
                    NumCuts *= 2;
                }
                else //get the optimal Number of Cuts, or NumCuts == Max_NumCuts
                {
                    if (DISPLAY_ALL) printf("The optimal NumCuts = %u\n",NumCuts);                  
                    t_n2c[dim] = NumCuts;
                    //printf("t_n2c[%u]=%u\n",dim,NumCuts);
                    done = 1;
                }// find the max NumCuts that satisfy "sm < spmf"
            }//end: for(done=0;done==0;)
        } //end: if(currState->b2c[dim]>0)
    } //end: for(dim=0;dim<DIM;dim++)

    //choose which dimension to i at
    //printf("before h2cdim\n");
    switch(H2CDIM)
    {
        case 1: *d2c = Min_Max_NumRules_Child(t_h2c,t_n2c,currState); break;
        //case 2: *d2c = Max_Distribution_Entropy(t_h2c,t_n2c,currState); break;
        case 3: *d2c = Min_Sm_Over_All_Dimensions(sm,currState); break;
        case 4: *d2c = Most_Distinct_Components(t_max_unique_id); break;
        default:
                printf("ERROR:while choose the method of Dimension Choosing\n");
                return FAIL;
    }
    //printf("after h2cdim\n");
    *b2c = currState->b2c[*d2c]; //current bit to i
    *n2c = t_n2c[*d2c]; //number to i
    *i2c = t_i2c[*d2c]; //interval of i

    //how to i
    NumCuts = *n2c; //now NumCuts equals the best number to i
    h2c->isUnique = (bool*)malloc(sizeof(bool)*NumCuts);
    for (i=0;i<NumCuts;i++)
    {
        h2c->isUnique[i] = t_h2c[*d2c]->isUnique[i];
    }

    h2c->ucID = (U16*)malloc(sizeof(U16)*NumCuts);
    for (i=0;i<NumCuts;i++)
    {
        h2c->ucID[i] = t_h2c[*d2c]->ucID[i];
    }

    h2c->numRules = (U32*)malloc(sizeof(U32)*NumCuts);
    for (i=0;i<NumCuts;i++)
    {
        h2c->numRules[i] = t_h2c[*d2c]->numRules[i];
    }

    h2c->ruleList = (U32**)malloc(sizeof(U32*)*NumCuts);
    for (i=0;i<NumCuts;i++)
    {
        if(h2c->numRules[i]>0)
        {
            h2c->ruleList[i] = (U32*)malloc(sizeof(U32)*h2c->numRules[i]);
            //printf("numRules=%u\t",h2c->numRules[i]);
            for (j=0;j<h2c->numRules[i];j++)
            {
                h2c->ruleList[i][j] = t_h2c[*d2c]->ruleList[i][j];
                //printf("h2cRuleList:%u\n",h2c->ruleList[i][j]);
            }
        }
    }
    //printf("dim=%u:b2c=%u\tNumCuts=%u\ti2c=%u\n",*d2c,*b2c,NumCuts,*i2c);
    //printf("h2cRuleList:%u %u %u %u\n",h2c->ruleList[0][0],h2c->ruleList[1][0],h2c->ruleList[2][0],h2c->ruleList[3][0]);

    h2c->numUniqueCut = t_max_unique_id[*d2c];

    // free other t_h2c
    for (dim=0; dim < NUMDIM; dim++)
    {
        if ((dim != *d2c) && (currState->b2c[dim] > 0))
        {
            for (i=0; i<t_n2c[dim]; i++)
            {
                if (!t_h2c[dim]->ruleList[i])
                    free(t_h2c[dim]->ruleList[i]);
            }
        }
    }
    free(tRuleList);
    return SUCCESS;
}

// minimize the max_j(NumRules(child_j))
U8 Min_Max_NumRules_Child(CUTINFO **h2c,U32 *n2c,STATE *state)
{
    U8 dim = 0,d2c = 0;
    U16 Max_NumRules[NUMDIM]={0,0,0,0,0};
    for (dim=0;dim<NUMDIM;dim++) // all dimensions
    {
        if (state->b2c[dim]>0)
        {
            U32 cut;
            Max_NumRules[dim] = h2c[dim]->numRules[0];
            // get the largest numRules among all the cuts in one dimension
            for (cut=0; cut<n2c[dim]; cut++) 
            {
                Max_NumRules[dim] = max(Max_NumRules[dim],h2c[dim]->numRules[cut]);
            }
        }
    }

    for (dim=0;dim<NUMDIM;dim++)
    {
        if (state->b2c[dim]>0)
        {
            d2c = dim;
            break;
        }
    }

    for (dim=0;dim<NUMDIM;dim++)
    {
        if (state->b2c[dim]>0)
        {
            // a less one
            if (Max_NumRules[dim]<Max_NumRules[d2c])
            {
                d2c = dim; // a better dimension
            }
        }
    }
    return d2c;
}


#ifdef USE_ENTROPY
// maximize the entropy of the distribution
U8 Max_Distribution_Entropy(CUTINFO **h2c,U32 *n2c,STATE *state)
{
    U8 d2c = 0;
    U8 dim = 0;

    for (dim=0;dim<NUMDIM;dim++) // get a dimension available
    {
        if (state->b2c[dim]>0)
        {
            d2c = dim;
            break;
        }
    }

    for (dim=0;dim<NUMDIM;dim++)
    {
        if (state->b2c[dim]>0)
        {
            if (getEntropy(h2c[d2c],n2c[d2c])<getEntropy(h2c[dim],n2c[dim])) // find a max entropy
            {
                d2c = dim;
            }
        }	
    }
    return d2c;
}

#endif

// minimize sm(C) in all dimensions
U8 Min_Sm_Over_All_Dimensions(U32 *sm,STATE *state)
{
    U8 dim=0,d2c=0;
    for (dim=0; dim<NUMDIM; dim++) // get a dimension available
    {
        if (state->b2c[dim] > 0)
        {
            d2c = dim;
            break;
        }
    }
    for (dim=0; dim<NUMDIM; dim++)
    {
        if (state->b2c[dim] > 0)
        {
            if (sm[dim] < sm[d2c])
            {
                d2c = dim;// select a dim that makes the least max_unique_id
            }
        }
    }
    //bug_on(d2c >= NUMDIM);
    return d2c;
}

// choose dimension by method 4:choose the dimension that has the most distinct components of rules
U8 Most_Distinct_Components(U16 *max_unique_id)
{
    U8 dim,d2c;
    for (dim=0,d2c=0; dim<NUMDIM; dim++)
    { 
        if (max_unique_id[dim]>max_unique_id[d2c])
        {
            d2c = dim;// select a dim that makes the least max_unique_id
        }
    }
    return d2c;
}

// Convert rules into gRuleSet
int convRules(pFiltSet pfiltset)
{
    U32 i=0;
    U32 sMask=0;
    U16 pMask=0;
    gRuleSet.numRules = pfiltset->numFilters;//rule num

    //write each rule into
    for(i=0;i<pfiltset->numFilters;i++)
    {
        gRuleSet.ruleList[i].pos=pfiltset->filtArr[i].cost;//priority

        //source IP
        sMask = pfiltset->filtArr[i].len[0];
        if(sMask==0)
            sMask = -1;
        else
            sMask = (1<<(32-sMask))-1;

#ifdef LITTLE_ENDIAN //x86
        gRuleSet.ruleList[i].ruleRange[0][0] = pfiltset->filtArr[i].ipHEX[0]&(~sMask);
        gRuleSet.ruleList[i].ruleRange[0][1] = pfiltset->filtArr[i].ipHEX[0]|sMask;
        //printf("%u:%u\t",gRuleSet.ruleList[i].ruleRange[0][0],gRuleSet.ruleList[i].ruleRange[0][1]);
#else //Sun
        gRuleSet.ruleList[i].ruleRange[0][0] = LBConvL(pfiltset->filtArr[i].ipHEX[0])&(~sMask);
        gRuleSet.ruleList[i].ruleRange[0][1] = LBConvL(pfiltset->filtArr[i].ipHEX[0])|(sMask);
        //printf("%u:%u\t",gRuleSet.ruleList[i].ruleRange[0][0],gRuleSet.ruleList[i].ruleRange[0][1]);
#endif

        //destination IP
        sMask = pfiltset->filtArr[i].len[1];//printf("sMask=%u\t",sMask);
        if(sMask==0)
            sMask = -1;
        else
            sMask = (1<<(32-sMask))-1;
#ifdef LITTLE_ENDIAN //x86
        gRuleSet.ruleList[i].ruleRange[1][0] = pfiltset->filtArr[i].ipHEX[1]&(~sMask);
        gRuleSet.ruleList[i].ruleRange[1][1] = pfiltset->filtArr[i].ipHEX[1]|sMask;
        //printf("%u:%u\t",gRuleSet.ruleList[i].ruleRange[1][0],gRuleSet.ruleList[i].ruleRange[1][1]);
#else //Sun
        gRuleSet.ruleList[i].ruleRange[1][0] = LBConvL(pfiltset->filtArr[i].ipHEX[1])&(~sMask);
        gRuleSet.ruleList[i].ruleRange[1][1] = LBConvL(pfiltset->filtArr[i].ipHEX[1])|(sMask);
        //printf("%u:%u\t",gRuleSet.ruleList[i].ruleRange[1][0],gRuleSet.ruleList[i].ruleRange[1][1]);
#endif

        //source port
        gRuleSet.ruleList[i].ruleRange[2][0] = pfiltset->filtArr[i].fromPort[0];
        gRuleSet.ruleList[i].ruleRange[2][1] = pfiltset->filtArr[i].toPort[0];
        //printf("%u:%u\t",gRuleSet.ruleList[i].ruleRange[2][0],gRuleSet.ruleList[i].ruleRange[2][1]);

        //destination port
        gRuleSet.ruleList[i].ruleRange[3][0] = pfiltset->filtArr[i].fromPort[1];
        gRuleSet.ruleList[i].ruleRange[3][1] = pfiltset->filtArr[i].toPort[1];
        //printf("%u:%u\t",gRuleSet.ruleList[i].ruleRange[3][0],gRuleSet.ruleList[i].ruleRange[3][1]);

        //protocol
        if(pfiltset->filtArr[i].protLen==0xff)
        {
            gRuleSet.ruleList[i].ruleRange[4][0] = pfiltset->filtArr[i].protPref;
            gRuleSet.ruleList[i].ruleRange[4][1] = pfiltset->filtArr[i].protPref;
        }else if(pfiltset->filtArr[i].protLen==0)
        {
            gRuleSet.ruleList[i].ruleRange[4][0] = 0;
            gRuleSet.ruleList[i].ruleRange[4][1] = 0xff;
        }else{
            printf("unkown protocol mask!\n");
            return FAIL;
        }
        //printf("%u:%u\n",gRuleSet.ruleList[i].ruleRange[4][0],gRuleSet.ruleList[i].ruleRange[4][1]);
    }
    return SUCCESS;
}
// build the decision tree
int BuildTree()
{
    //clear gTree first
    gTree.avgDepth = 0.0;
    gTree.maxDepth = 0;
    gTree.numLeafNodes = 0;
    gTree.sum_LeafDepth = 0;

    // VARIABLES
    U32 i, dim;
    STATE *currState; //save current State, and then copy to gTree

    // INITIALIZATION
    if (gTree.root != NULL)
    {
        free(gTree.root);
    }
    // tree node
    gTree.root = (TREENODE*)malloc(sizeof(TREENODE)); //global variable
    gTree.numNode = 1;
    gTree.root->depth = 0;

    // count
    gResult.totalMem = 0; //HiCuts,habs,nm
    if (!IF_NM) //HiCuts,habs
    {
        gResult.totalMem += SIZE_TREENODE; //the memory of root node:i info
    }

    // state
    currState = (STATE*)malloc(sizeof(STATE));
    currState->numRules = gRuleSet.numRules; //gRuleSet is a global variable, all rules in
    currState->ruleList = (U32*)malloc(gRuleSet.numRules*sizeof(U32)); //free at last
    for (i=0; i<gRuleSet.numRules; i++)  
    {
        currState->ruleList[i] = i; //from 0 to gRuleSet.numRules
        //printf("currState.ruleList:%u\n",currState->ruleList[i]);
    }
    currState->nextState = NULL;
    currState->b2c[0] = 32; currState->b2c[1] = 32; // IPv4
    currState->b2c[2] = 16; currState->b2c[3] = 16; // port range
    currState->b2c[4] = 8; // protocol

    currState->range[0][0] = 0; currState->range[0][1] = 0xffffffff; // IP source
    currState->range[1][0] = 0; currState->range[1][1] = 0xffffffff; // IP destination
    currState->range[2][0] = 0; currState->range[2][1] = 0xffff; // port source
    currState->range[3][0] = 0; currState->range[3][1] = 0xffff; // port destination
    currState->range[4][0] = 0; currState->range[4][1] = 0xff; // protocol


    currState->currTreeNode = gTree.root; //from the root NODE
    currState->currTreeNode->numRules= gRuleSet.numRules;
    // enqueue
    gStateQueue.headState = currState; //well, gStateQueue is also a global variable
    gStateQueue.rearState = currState;

    // MAIN LOOP
    while (currState) //if headState == NULL, then there are no node to i
    {
        // make sure the leaf-node only has BINTH=1 rule 
        if ((!currState->b2c[0])&&/*{{{*/
                (!currState->b2c[1])&&
                (!currState->b2c[2])&&
                (!currState->b2c[3])&&
                (!currState->b2c[4])) { //cut into one point now
            if (currState->numRules > 1) {
                U32 tmp = currState->ruleList[0];
                //printf("leaf:%u\n",tmp);
                bug_on (currState->ruleList == NULL);
                if(currState->ruleList!=NULL)free(currState->ruleList);
                currState->ruleList = (U32*)malloc(sizeof(U32)); // XXX hmm
                *currState->ruleList = tmp;
                currState->numRules = 1;
            }
        }/*}}}*/

        // Leaf Nodes(rules less than BINTH):set the leaf-node label
        if(currState->numRules <= BINTH)
        {
            //gTree.numLeafNodes++; //number of leafNodes
            //gTree.sum_LeafDepth += currState->currTreeNode->depth; //add current depth into sum
            //if(gTree.maxDepth < currState->currTreeNode->depth) //tree depth = the max leaf depth
            //{
            //    //printf("gtree.depth=%u\n",gTree.maxDepth);
            //    gTree.maxDepth = currState->currTreeNode->depth;
            //}
            currState->currTreeNode->d2c = 0xff; // leaf node label
            currState->currTreeNode->b2c = 0xff; // leaf node label
            currState->currTreeNode->numCuts = 1; //leaf node label
            currState->currTreeNode->numRules = currState->numRules; // number of curr rules
            currState->currTreeNode->ptr = (TREENODE**)malloc(currState->numRules*sizeof(U32));
            memcpy((U32*)currState->currTreeNode->ptr,(U32*)currState->ruleList, currState->numRules*sizeof(U32)); //as to leafNode,ptr just points to the rules(<=BINTH)
            //printf("leafrule=%u\n",(U32)*currState->currTreeNode->ptr);
            // count for the leaf nodes:only store some rules No
            //gResult.totalMem += currState->numRules*sizeof(U32);
            //printf("buildtree:leaf\n");
        }
        else// INTERNAL NODES
        {
            //  GET CUT INFO
            U8 d2c = 0,b2c = 0;    // bit to i
            U32 n2c = 0,i2c = 0;    // interval of each i
            CUTINFO h2c;    // how to i

            U32 nextCut=0;            
            STATE   *t_State=NULL;
            //printf("down1\n");

            if (GetCutInfo(&d2c, &b2c, &n2c, &i2c, &h2c)!=SUCCESS)
            {
                printf("\n>>ERROR in DimToCut()");
                return (FAIL);
            }
            //printf("d2c=%u,b2c=%u,n2c=%u\n",d2c,b2c,n2c);
            //printf("numrules:%u %u %u %u\n",h2c.numRules[0],h2c.numRules[1],h2c.numRules[2],h2c.numRules[3]);
            //printf("ruleofcuts:%u %u %u %u\n",h2c.ruleList[0][0],h2c.ruleList[1][0],h2c.ruleList[2][0],h2c.ruleList[3][0]);
            gTree.numNode += n2c; //tree nodes

            // CREATE CHILDNODE
            currState->currTreeNode->d2c = d2c; //currState->currTreeNode now store the d2c
            currState->currTreeNode->b2c = b2c;
            currState->currTreeNode->numCuts = n2c; //record the n2c into treeNode
            currState->currTreeNode->ptr = (TREENODE**)malloc(n2c*sizeof(TREENODE*));

            //every point to the child nodes is set to NULL first
            memset(currState->currTreeNode->ptr, 0, n2c*sizeof(TREENODE*));

            // update point array and create child-nodes
            for (i=0; i<n2c; i++)
            {       
                //this if{} making sure that only unique cuttings go into this block
                if (!currState->currTreeNode->ptr[i]) // found an empty ptr: ptr[i],create child node and set pointer to it
                {
                    currState->currTreeNode->ptr[i] = (TREENODE*)malloc(sizeof(TREENODE));
                    currState->currTreeNode->ptr[i]->depth = currState->currTreeNode->depth+1;

                    // set state for this child
                    t_State = (STATE*) malloc(sizeof(STATE));
                    t_State->currTreeNode = currState->currTreeNode->ptr[i]; //temporary for child nodes

                    //copy range to t_State
                    for (dim=0; dim<NUMDIM; dim++)
                    {
                        t_State->b2c[dim] = currState->b2c[dim];
                        t_State->range[dim][0] = currState->range[dim][0];
                        t_State->range[dim][1] = currState->range[dim][1];
                    }
                    t_State->b2c[d2c] = currState->b2c[d2c] - getLog_2(n2c);
                    t_State->range[d2c][0] = t_State->range[d2c][0] + i2c*i;
                    t_State->range[d2c][1] = t_State->range[d2c][0] + i2c-1;
                    t_State->numRules = h2c.numRules[i];
                    t_State->ruleList = h2c.ruleList[i];
                    //printf("intervalrule:%u\n",*h2c.ruleList[i]);
                    t_State->nextState = NULL;
                    // enqueue this state
                    gStateQueue.rearState->nextState = t_State;
                    gStateQueue.rearState = t_State;

                    // this for{} sets the undealled pointers belonging to the same unique cuttings
                    for (nextCut=i+1; nextCut<n2c; nextCut++)
                    {
                        if (h2c.ucID[i] == h2c.ucID[nextCut])
                        {
                            currState->currTreeNode->ptr[nextCut] = currState->currTreeNode->ptr[i];
                        }
                    }
                    //printf("buildtree:internal\n");
                }// end else
            }// end for each cut

        }// end for internal nodes

        //  DEQUEUE
        gStateQueue.headState = currState->nextState;//////////////////////////////////////////////////////////////////////////

        free(currState->ruleList);
        free(currState);

        currState = gStateQueue.headState;

    }// end for while
    gTree.avgDepth = (float)gTree.sum_LeafDepth/(float)gTree.numLeafNodes; //get the avg_Depth

    return SUCCESS;
}

// Return the sum of the first length bits  in HABS // See Hack, how to optimize bit count for 8-bit vector
/*U16 bitCount(U8 HABS,U8 length)
{
    U16 i = 0,count = 0;
    U8 bitmask = 1;
    bug_on(length > SIZE_HABS);
    HABS >>= (SIZE_HABS-length);   // JMG: SIZE_HABS=1<<3 (8).
    for (i=0;i<length;i++)
    {
        count += HABS&bitmask;//
        HABS >>= 1;
    }
    return count;
}*/

// Return the specified bit value of HABS
/*U8 getBit(U8 HABS,U8 bitPos)
{
    U8 bitmask = 1<<(7-bitPos);
    bug_on(bitPos>7);
    return (HABS&bitmask)>>(7-bitPos);
}*/
/*U16 genCPAnodeNum(U8 HABS, U16 nodeNum)
{
    U16 CPAnodeNum = SIZE_CPA_UNIT*(bitCount(HABS,nodeNum/SIZE_CPA_UNIT+1)-1)+nodeNum%SIZE_CPA_UNIT;
    return CPAnodeNum;
}*/

